# Descriere cerinta proiect

## Cerinta

- cand utilizatorul acceseaza pagina trebuie sa vada un calcullator ( creare interfata HTML )
- utilizatorul poate sa selecteze primul numar ( primul numar este reprezentat de selectia cumulativa a tuturor numelor pana cand apasa pe un operator, exceptia PUNCTUL)
- se apasa operatorul dupa primu numar
- se introduce al doilea numar
- selectam un alt operator si continuam operatia
- displayul trebuie sa ne arate tot istoricul opeartiilor si rezultatul sa fie afisat dupa ce apasam operatorul egal.

### cerinte tehnice

1. creare interfata HTML
   ( fiecare buton sa aiba un id)
   ( fiecare element are un id unic)
2. crearea de logica pt a stoca pasii utilizatorului. si pt a depistra fiecare nr si operator in parte.
3. cand apasam egal executam formula matematica, executam toate formulele matematice.
4. in display afisam pasii 2 si 3.
5. daca avem un operator selectot si apasam alt operator il suprasriem pe cel anterior.
6. butonul backspace sterge cate o cifra din numarul curent ( mai mare decat 0 )
7. butonul CE sterge tot numarul nu doar o cifra
8. butonul C reseteaza tot calculatorul.
